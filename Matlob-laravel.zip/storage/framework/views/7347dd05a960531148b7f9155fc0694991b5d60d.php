<?php $__env->startSection('title'); ?>
    الشكاوي
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .Que{
            display: none;
        }
        .active-Que{
            display: block!important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="container">

    <div class="row">
        <?php echo $__env->make('front.Company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-10">
            <div class="col-md-12">
                <div class="row jobs">
                    <div class="col-md-6">
                        <h5> الشكاوي
                        </h5>
                    </div>

                </div>
            </div>
            <hr>
    <!-- start tab -->

        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <!-- collapse item 1 -->
                <div id="accordion">
                    <?php
                    $active = 'show';
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <h5 class="mb-0">الاسم :  <?php echo e($faq->User->name); ?>

                                    <button class="btn btn-link button-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapseOne">
                                        <i class="fa fa-plus-circle" aria-hidden="true"></i>
                                    </button>
                                </h5>
                            </div>
                            <div id="collapseOne<?php echo e($key); ?>" class="collapse <?php echo e($active); ?>" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body">
                                    <?php echo e($faq->description); ?>

                                </div>
                            </div>
                        </div>

                        <?php
                        $active = '';
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script>

        $('.nav-link').click(function() {

            $('.nav-link').removeClass("active");
            $('.nav-link').removeClass("active-item");
            $('.tab-pane').removeClass("active");
            $('.tab-pane').removeClass("show");
            $(this).addClass('active');
            $(this).addClass('active-item');
            var target = $(this).data('bs-target');
            $(target).addClass('active show')

        });
        // $('.button-link').click(function() {
        //     out =    ' <i class="fa fa-minus-circle" aria-hidden="true"></i>';
        //
        //     $(this).html(out)
        //
        // });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/Company/Complaints.blade.php ENDPATH**/ ?>