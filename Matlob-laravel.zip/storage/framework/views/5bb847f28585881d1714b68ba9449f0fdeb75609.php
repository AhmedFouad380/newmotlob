<?php $__env->startSection('title'); ?>
    الصفحة الشخصية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- this is content of company -->
    <section class="container container-space">
        <div class="row">
          <?php echo $__env->make('front.Company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-10">
                <!-- row -->
                <div class="col-md-12">
                    <div class="company-header">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="company-image">
                                    <div class="bottom-company"><button>تعديل</button></div>
                                </div>
                            </div>

                            <div class="col-md-7 company-line">
                                <h5>شركة ميديا جروب</h5>
                                <p>
                                    <i class="fa fa-wrench" aria-hidden="true"></i>
                                    تخصص اعمال ادارية
                                </p>
                                <span class="gray-color">
                                                <i class="fa fa-cog" aria-hidden="true"></i>
                                                مجال الموار البشرية
                                            </span>
                            </div>

                            <div class="col-md-3">
                                <a class="btn" >تعديل</a>
                                <div class="company-socail">
                                    <i class="fa fa-facebook" aria-hidden="true"></i>
                                    <i class="fa fa-twitter" aria-hidden="true"></i>
                                    <i class="fa fa-instagram" aria-hidden="true"></i>
                                    <i class="fa fa-youtube" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="alert">
                        <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                        تم إخفاء اسم الشركة بناءَ على رغبة صاحب العمل لرغبته في تلقي السير الذاتية على موقع مطلوب للإطلاع عليها واختيار أفضل المتقدمين دون التردد على مقر الشركة
                        مما يسبب ضغط على إدارة الموارد البشرية أو الفروع ويعطل سير العمل اليومي بها </div>

                </div>

                <div class="col-md-12">
                    <div class="info-head">
                        <div class="row">
                            <div class="col-md-8">
                                <h5>
                                    <i class="fa fa-headphones" aria-hidden="true"></i>
                                    معلومات التواصل</h5>
                            </div>
                            <div class="col-md-4">
                                <a class="btn blue"> تعديل </a>
                            </div>
                        </div>
                    </div>
                    <div class="company-info">
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li class="blue">
                                        <label>
                                            <i class="fa fa-building-o" aria-hidden="true"></i>
                                            الشركة
                                        </label>
                                    </li>
                                    <li class="gray-color">
                                        <label>
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                            الهاتف
                                        </label>
                                        <span class="black">
                                                                  01020304050
                                                              </span>

                                    </li>
                                    <li class="gray-color">
                                        <label >
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                            البريد
                                        </label>
                                        <span class="black">
                                                                  info@mattlob.com
                                                              </span>
                                    </li>
                                    <li class="gray-color">
                                        <label >
                                            <i class="fa fa-globe" aria-hidden="true"></i>
                                            الموقع
                                        </label>
                                        <span class="black">
                                                                  Mattlob.com
                                                                  </span>
                                    </li>
                                    <li class="gray-color">
                                        <label>
                                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                                            العنوان
                                        </label>
                                        <span class="black">
                                                              Mattlob.com
                                                              </span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li class="blue">
                                        <label>
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            المدير
                                        </label>

                                    </li>
                                </ul>

                            </div>


                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="info2-head">
                        <div class="row">
                            <div class="col-md-8 ">
                                <h5>
                                    <i class="fa fa-files-o" aria-hidden="true"></i>
                                    مستندات الشركة
                                </h5>
                            </div>
                            <div class="col-md-4">
                                <a class="btn blue"> تعديل </a>
                            </div>
                        </div>
                    </div>
                    <div class="info2-head-data">
                        <div class="row row-margin">
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-7">
                                        <p class="gray-color"> <i class="fa fa-id-card-o" aria-hidden="true"></i> رقم البطاقة الضريبية</p>
                                        <p class="gray-color"> <i class="fa fa-qrcode" aria-hidden="true"></i> رقم السجل التجاري</p>

                                    </div>
                                    <div class="col-md-5 p-left">
                                        <p>64666</p>
                                        <p>655654</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5 row-border">
                                <div class="row">
                                    <div class="col-md-7">
                                        <p class="gray-color"> <i class="fa fa-file-text-o" aria-hidden="true"></i> السجل التجاري</p>
                                        <p class="gray-color"><i class="fa fa-file-archive-o" aria-hidden="true"></i> البطاقة الضريبية</p>
                                    </div>
                                    <div class="col-md-5 p-left">
                                        <a class="blue">  <i class="fa fa-download" aria-hidden="true"></i> تحميل</a>
                                        <a  class="blue a"> <i class="fa fa-download" aria-hidden="true"></i> تحميل</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="row">
                                    <div class="col-md-7">
                                        <p class="gray-color"> <i class="fa fa-folder-o" aria-hidden="true"></i> خطاب التحقق</p>
                                        <p class="gray-color"> <i class="fa fa-file-o" aria-hidden="true"></i> اتفاقية التوظيف</p>
                                    </div>
                                    <div class="col-md-5 p-left">
                                        <a  class="blue">  <i class="fa fa-download" aria-hidden="true"></i> تحميل</a>
                                        <a  class="blue a"> <i class="fa fa-download" aria-hidden="true"></i> تحميل</a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/Front/Company/Profile.blade.php ENDPATH**/ ?>