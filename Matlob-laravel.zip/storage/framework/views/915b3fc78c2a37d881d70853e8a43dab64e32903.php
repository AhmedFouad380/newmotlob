<?php $__env->startSection('title'); ?>
    الباقات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <form>
        <section class="container">
            <div class="row">
                <div class="col-md-12 cv-offer-title">
                    <h5 class="h-title">احصل الآن على اشتراكك لتتمكن من تعديل سيرتك الذاتية وطباعتها في أي وقت</h5>
                    <p class="p-title">اضغط على الباقة المناسبة لك و اشترك بها من الآن</p>
                </div>
            </div>
            <section class="cv-offer-center">
                <?php $__currentLoopData = \App\Models\Package::where('is_active','active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a  style="text-decoration: none" href="<?php echo e(url('PaymentUrl',$Package->id)); ?>">
                <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                    light
                    <?php endif; ?>
                    ">
                    <h6><?php echo e($Package->title); ?></h6>
                    <h1><?php echo e($Package->price); ?></h1>
                    <p class="cv-1">جنيه مصري</p>
                    <p class="p-cv2">
                        <span class="p1-span"><?php if($Package->type == 'time'): ?> لمدة <?php else: ?> لعدد <?php endif; ?> </span>
                        <span class="p2-span"><?php echo e($Package->count); ?></span>
                        <span class="p3-span"><?php if($Package->type == 'time'): ?> شهور <?php else: ?> مرة <?php endif; ?> </span>
                    </p>
                    <p class="p-cv3"><?php echo e($Package->description); ?></p>
                </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <hr class="offer-line">
            <div class="row cv-btn-offer">
                <a href="<?php echo e(url('cv-maker-step10')); ?>" class=" btn  btn-theme2">
                    رجوع للخلف
                </a>
            </div>
        </section>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Matlob-laravel\resources\views/front/Packages.blade.php ENDPATH**/ ?>