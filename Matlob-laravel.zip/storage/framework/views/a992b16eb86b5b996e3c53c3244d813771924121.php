<?php $__env->startSection('title'); ?>
    انشاء السيرة الذاتية
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <!-- this is content -->

             <section class="container">
                 <form method="post" action="<?php echo e(url('store-knows')); ?>">
                    <?php echo csrf_field(); ?>
                 <div class="row cv-maker">

                     <div class="col-md-3 cv">
							<div>
								<h6>الشهادات و الدورات </h6>
								<hr>
										<ul class="ul">
                                            <li class="green"><span class="green">1</span>  <a class="green" href="<?php echo e(url('cv-maker')); ?>">المعلومات الشخصية</a></li>
                                            <li class="green"><span class="green">2</span> <a class="green" href="<?php echo e(url('cv-maker-step2')); ?>">الموجــز</a></li>
                                            <li class="green"><span class=" green">3</span> <a  class="green"  href="<?php echo e(url('cv-maker-step2')); ?>">التعليم</a></li>
                                            <li class="green"><span class="green ">4</span> <a class="green"  href="<?php echo e(url('cv-maker-step4')); ?>">الخبــرات </a></li>
                                            <li class="green"><span class="green ">5</span> <a class="green"  href="<?php echo e(url('cv-maker-step5')); ?>"> المهــارات </a></li>
                                            <li class="green"><span class="green ">6</span> <a class="green" href="<?php echo e(url('cv-maker-step6')); ?>">اللغات</a> </li>
                                            <li class="green"><span class="green ">7</span> <a class="green" href="<?php echo e(url('cv-maker-step7')); ?>">المؤتمرات  و الدورات</a></li>
                                            <li class="blue"><span class="blue border-blue">8</span> <a class="blue" href="<?php echo e(url('cv-maker-step8')); ?>">المعرفين</a></li>
                                            <li><span>9</span><a href="<?php echo e(url('cv-maker-step9')); ?>">المنظمات</a></li>
                                            <li><span>10</span><a href="<?php echo e(url('cv-maker-step10')); ?>" >الخطوة النهــائية</a></li>
										</ul>

							</div>
					    </div>

						<div class="col-md-9 cv-form">
							<h5>اضف ملرومات المعرفين</h5>
							<p>المعرف يمكن ان يكون زميل عمل او مدير سابق او استاذ جامعه</p>
						        	<div class="row">

										  <div class="form-group col-md-6">
											  <label> الاسم  </label>
											  <input type="text" class="form-control" required name="name" placeholder="اسم ">
										  </div>

                                        <div class="form-group col-md-6">
                                            <label> المسمى الوظيفي  </label>
                                            <input type="text" class="form-control" required name="job_title" placeholder="المسمى الوظيفي ">
                                        </div>
                                    <div class="form-group col-md-6">
                                        <label> الشركة</label>
                                        <input type="text" class="form-control" name="company" placeholder="اسم الشركة">
                                    </div>

                                    </div>
							    	<div class="row">
										  <div class="form-group col-md-4">
                                              <label> البريد الالكتروني</label>
                                              <input type="text" class="form-control" name="email" placeholder="البريد الالكتروني">
										  </div>
                                        <div class="form-group col-md-4">
                                            <label>رقم الهاتف </label>
                                            <input type="number" class="form-control" required name="phone" placeholder="رقم الهاتف">
                                        </div>
                                         <button type="submit" class="btn btn-primary btn-theme add" >
                                            + إضافة
                                          </button>
                                    </div>
								   </div>


















                    </div>
					 <hr>
                     <section >
                         <div class="row">
                             <div class="col-md-3">
                             </div>
                             <div class="col-md-9">
                                 <h5>راجع المعرفين</h5>
                                 <div class="row">
                                     <?php $__currentLoopData = Auth::guard('web')->user()->knows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <div class="col-md-4 ">
                                             <div class="data">
                                                 <i class="fa fa-trash-o delete" data-id="<?php echo e($data->id); ?>" aria-hidden="true"></i>
                                                 الاسم : <?php echo e($data->name); ?> <br>
                                                 رقم الهاتف : <?php echo e($data->phone); ?>   <br>
                                                  البريد الالكتروني : <?php echo e($data->email); ?>

                                                  المسمى الوظيفي : <?php echo e($data->job_title); ?> <br>
                                                   الشركة : <?php echo e($data->company); ?>


                                             </div>
                                         </div>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </div>
                             </div>
                         </div>
                     </section>
                 <hr>
					 <div class="row cv-btn">
						<a type="button" class=" btn  btn-theme2" href="<?php echo e(url('cv-maker-step7')); ?>">
							رجوع للخلف
						  </a>
						<a href="<?php echo e(url('cv-maker-step9')); ?>" type="button" class="btn btn-primary btn-theme" >
							الخطوة التالية
						  </a>

					 </div>
                      </form>
              </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
        <script type="text/javascript">

            $(".delete").on("click", function () {
                var dataList = $(this).data('id');

                if (dataList) {
                    Swal.fire({
                        title: "تحذير.هل انت متأكد؟!",
                        text: "",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#f64e60",
                        confirmButtonText: "نعم",
                        cancelButtonText: "لا",
                        closeOnConfirm: false,
                        closeOnCancel: false
                    }).then(function (result) {
                        if (result.value) {
                            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                            $.ajax({
                                url: '<?php echo e(url("delete-knows")); ?>',
                                type: "get",
                                data: {'id': dataList, _token: CSRF_TOKEN},
                                dataType: "JSON",
                                success: function (data) {
                                    if (data.message == "Success") {
                                        $("input:checkbox:checked").parents("tr").remove();
                                        Swal.fire("نجاح", "تم الحذف بنجاح", "success");
                                        location.reload();
                                    } else {
                                        Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                    }
                                },
                                fail: function (xhrerrorThrown) {
                                    Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                }
                            });
                            // result.dismiss can be 'cancel', 'overlay',
                            // 'close', and 'timer'
                        } else if (result.dismiss === 'cancel') {
                            Swal.fire("ألغاء", "تم الالغاء", "error");
                        }
                    });
                }
            });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Matlob-laravel\resources\views/front/cvmaker8.blade.php ENDPATH**/ ?>