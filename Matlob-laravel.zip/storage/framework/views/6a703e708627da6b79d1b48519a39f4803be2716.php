<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/admin/ExperienceSpecialization/modelShow.blade.php ENDPATH**/ ?>