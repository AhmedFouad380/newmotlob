<?php $__env->startSection('title'); ?>
    انشاء السيرة الذاتية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- this is content -->

    <section class="container">
        <div class="row cv-maker">
            <div class="col-md-3 col-11 cv">
                <div>
                    <h6>مراحل تصميم السيرة الذاتية </h6>
                    <hr>
                    <ul class="ul">
                        <li class="blue"><span class="blue border-blue">1</span>  <a class="blue" href="<?php echo e(url('cv-maker')); ?>">المعلومات الشخصية</a></li>
                        <li ><span >2</span> <a href="<?php echo e(url('cv-maker-step2')); ?>">الهدف المهني </a></li>
                        <li ><span >3</span> <a href="<?php echo e(url('cv-maker-step3')); ?>">التعليم</a></li>
                        <li ><span >4</span> <a href="<?php echo e(url('cv-maker-step4')); ?>">الخبــرات </a></li>
                        <li><span>5</span> <a href="<?php echo e(url('cv-maker-step5')); ?>"> المهــارات </a></li>
                        <li ><span >6</span> <a href="<?php echo e(url('cv-maker-step6')); ?>">اللغات</a> </li>
                        <li><span>7</span> <a href="<?php echo e(url('cv-maker-step7')); ?>">المؤتمرات  و الدورات</a></li>
                        <li><span>8</span><a href="<?php echo e(url('cv-maker-step8')); ?>">المعرفين</a></li>
                        <li><span>9</span><a href="<?php echo e(url('cv-maker-step9')); ?>">المنظمات</a></li>
                        <li><span>10</span><a href="<?php echo e(url('cv-maker-step10')); ?>" >الخطوة النهــائية</a></li>

                    </ul>

                </div>
            </div>

            <div class="col-md-8 col-11 cv-form">
                <h5>لنبدأ بالمعلومات الشخصية </h5>
                <p>قم بتضمين اسمك الكامل و طريقة واحدة على الأقل للوصول إليك من قبل أصحاب العمل </p>
                <form method="post" action="cv-maker-step2" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="form-group col-md-6 col-12">
                            <label> الصورة </label>
                            <input type="file"  class="dropify form-control" data-default-file="<?php echo e(Auth::guard('web')->user()->info->image); ?>" name="image" >
                        </div>

                    </div>
                    <div class="row mob-margin">

                        <div class="form-group col-md-4 col-6">
                            <label> الإسم الأول </label>
                            <input type="text" required class="form-control" value="<?php echo e(Auth::guard('web')->user()->info->firstname); ?>" name="firstname" placeholder="الإسم الأول">
                        </div>
                        <div class="form-group col-md-4 col-6">
                            <label>  الإسم الأخير</label>
                            <input type="text" required class="form-control"  value="<?php echo e(Auth::guard('web')->user()->info->lastname); ?>" name="lastname" placeholder="الإسم الأخير">
                        </div>

                        <div class="form-group col-md-4 col-12">
                            <label> تاريخ الميلاد </label>
                            <input type="date" required class="form-control" disabled name="date"  value="<?php echo e(Auth::guard('web')->user()->birth_date); ?>">
                        </div>

                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 col-6">
                            <label>  الهاتف</label>
                            <input type="tel" disabled required class="form-control"  value="<?php echo e(Auth::guard('web')->user()->phone); ?>" name="phone" placeholder="الهاتف">
                        </div>
                        <div class="form-group col-md-4 col-6">
                            <label> البريد الإلكتروني </label>
                            <input type="email" disabled required class="form-control" value="<?php echo e(Auth::guard('web')->user()->email); ?>" name="email" placeholder="البريد الالكتروني">
                        </div>
                        <div class="form-group col-md-4 col-12">
                            <label>  المسمى الوظيفي</label>
                            <input type="text" required class="form-control"  value="<?php echo e(Auth::guard('web')->user()->info->job_title); ?>" name="job_title" placeholder="المسمى الوظيفي">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 col-6">
                            <label>  الدولة</label>
                            <?php $Countries = app('App\Models\Country'); ?>

                            <select class="form-control" required id="country3" name="country_id">
                                <?php if(Auth::guard('web')->user()->info->country_id): ?>
                                <?php $__currentLoopData = $Countries->where('is_active','active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(Auth::guard('web')->user()->info->country_id == $Country->id): ?>  selected <?php endif; ?> value="<?php echo e($Country->id); ?>"><?php echo e($Country->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $Countries->where('is_active','active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(Auth::guard('web')->user()->country_id == $Country->id): ?>  selected <?php endif; ?> value="<?php echo e($Country->id); ?>"><?php echo e($Country->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php $City = app('App\Models\City'); ?>
                        <div class="form-group col-md-4 col-6">
                            <label>  المحافظة</label>
                            <select class="form-control"  required id="city3" name="city_id">
                                <?php if(Auth::guard('web')->user()->info->city_id): ?>
                                <?php if(Auth::guard('web')->user()->info->city_id): ?>
                                    <option value="<?php echo e(Auth::guard('web')->user()->info->city_id); ?>"><?php echo e($City->find(Auth::guard('web')->user()->info->city_id)->name); ?></option>
                                <?php endif; ?>
                                <?php else: ?>
                                        <option value="<?php echo e(Auth::guard('web')->user()->city_id); ?>"><?php echo e($City->find(Auth::guard('web')->user()->city_id)->name); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php $State = app('App\Models\State'); ?>

                        <div class="form-group col-md-4 col-6">
                            <div class="form-group">
                                <label for="state" >المركز *</label>
                                <select class="form-control wizard-required" id="state2" name="state_id">
                                    <?php if(Auth::guard('web')->user()->info->state_id): ?>
                                        <?php if(Auth::guard('web')->user()->info->state_id): ?>
                                            <option value="<?php echo e(Auth::guard('web')->user()->info->state_id); ?>"><?php echo e($State->find(Auth::guard('web')->user()->info->state_id)->name); ?></option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e(Auth::guard('web')->user()->state_id); ?>"><?php echo e($State->find(Auth::guard('web')->user()->state_id)->name); ?></option>
                                    <?php endif; ?>
                                </select>
                                <div class="wizard-form-error"></div>
                            </div>
                        </div>
                        <?php $Village = app('App\Models\Village'); ?>

                        <div class="form-group col-md-4 col-6">
                            <div class="form-group">
                                <label for="state" >القرية او الحي *</label>
                                <select class="form-control wizard-required" id="village2" name="village_id">
                                    <?php if(Auth::guard('web')->user()->info->village_id): ?>
                                        <?php if(Auth::guard('web')->user()->info->village_id): ?>
                                            <option value="<?php echo e(Auth::guard('web')->user()->info->village_id); ?>"><?php echo e($Village->find(Auth::guard('web')->user()->info->village_id)->name); ?></option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e(Auth::guard('web')->user()->village_id); ?>"><?php echo e($Village->find(Auth::guard('web')->user()->village_id)->name); ?></option>
                                    <?php endif; ?>
                                </select>
                                <div class="wizard-form-error"></div>
                            </div>
                        </div>

                        <div class="form-group col-md-4 col-12">
                            <label>العنوان بالتفصيل  </label>
                            <input type="text" class="form-control" name="address"  value="<?php echo e(Auth::guard('web')->user()->info->address); ?>" placeholder="العنوان بالتفصيل">
                        </div>

                    </div>


            </div>







        </div>
        <hr>
        <div class="row cv-btn">
            <div class="col-md-12 col-12">
                <div class="btn-text">
                    <button type="submit" class="btn btn-primary btn-theme" style="font-size: 12px">
                        الخطوة التالية
                    </button>
                </div>
            </div>

        </div>
        </form>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js" integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>

        $('.dropify').dropify();

        $("#country3").on('click , change',function () {
            var wahda = $(this).val();

            if (wahda != '') {
                $.get("<?php echo e(URL::to('/get-Cities')); ?>" + '/' + wahda, function ($data) {
                    $('#city3').html($data);
                });
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/cvmaker.blade.php ENDPATH**/ ?>