<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('website/assets/css/bootstrap.css')); ?>"  type="text/css">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('website/assets/css/all.min.css')); ?>" type="text/css">
    <link rel="stylesheet"  type="text/css" media="screen" href="<?php echo e(asset('website/assets/css/cv.css')); ?>" type="text/css">
    <title>مطلوب || سيرة ذاتية</title>

</head>
<style media="print">
    @media  print {



    .resume4-color {
        background-color: #FAC801 !important;
        -webkit-print-color-adjust: exact;
    }
    .yellow-div4 {
        background-color: #FAC801 !important;
        -webkit-print-color-adjust: exact;

    }
    }

</style>
<body style="direction: ltr;">

<!--  this is resume 4  -->

<section class=" container a4-width " id="invoice">
    <section class="row">
        <div class="col-lg-4 col-md-4 col-4 change-row">
            <div class="resume4-img">
                <div class="resume4-image">
                    <?php if(isset(Auth::guard('web')->user()->info->image)): ?>
                        <img src="<?php echo e(Auth::guard('web')->user()->info->image); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/images/image.png')); ?>">
                    <?php endif; ?>
                </div>
                <div class="resume4-color">
                </div>
            </div>
            <div class="margin4">
                <div class="resume4-contact">
                    <div class="resume4-bottom">
                        <h4> Contact us </h4>
                        <div class="row">
                            <div class="col-md-2 col-lg-2 col-2">
                                <div class="icon-yellow-4">
                                            <span>
                                                <i class="fa fa-phone" aria-hidden="true"></i>
                                            </span>
                                    <span>
                                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                            </span>
                                    <span>
                                                <i class="fa fa-home" aria-hidden="true"></i>
                                            </span>
                                </div>
                            </div>
                            <div class="col-md-10 col-10 ">
                                <div class="contact4-span">
                                    <span><?php echo e(Auth::guard('web')->user()->info->phone); ?></span>
                                    <span><?php echo e(Auth::guard('web')->user()->info->email); ?></span>
                                    <span><?php echo e(Auth::guard('web')->user()->info->City->name); ?> -
                                    <?php echo e(Auth::guard('web')->user()->info->Country->name); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="resume4-education">
                    <div class="resume4-bottom">
                        <h4>Education</h4>
                        <?php $__currentLoopData = Auth::guard('web')->user()->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="about4-education">
                                <p class="resume4-date" >( <?php echo e(\Carbon\Carbon::parse($edu->graduation_date)->format('Y')); ?> )</p>
                                <p  class="resume4-dgree"><?php echo e($edu->qualification); ?> </p>
                                <p  class="resume4-dgree">  <?php echo e($edu->area); ?></p>
                                <p class="resume4-universtiy" ><?php echo e($edu->name); ?></p>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <div class="resume4-languge">
                    <div>
                        <?php $lang = app('App\Models\Lang'); ?>

                        <h4 class="">Languages</h4>
                        <div class="row div4">
                            <?php $__currentLoopData = Auth::guard('web')->user()->LangRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2 col-2">
                                    <div class="squre squre-color4"></div>
                                </div>
                                <div class="col-md-10 col-10">
                                    <div class="captalize-div "><?php echo e($lang->find($edu->lang_id)->name); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-8 change-row">
            <div class="left-resum4">
                <div class="row">
                    <div class="col-md-11 col-11">
                        <div>
                            <h1 class="h1-resume4">
                                <?php echo e(Auth::guard('web')->user()->info->firstname); ?>    <?php echo e(Auth::guard('web')->user()->info->lastname); ?>



                            </h1>
                            <span class="span4header">
                                <?php echo e(Auth::guard('web')->user()->info->job_title); ?>

                            </span>
                        </div>
                    </div>
                    <div class="col-md-1 col-1">
                        <div class="yellow-div4"></div>
                    </div>
                </div>
                <div class="profile4 resume4-bottom">
                    <h4>profile</h4>
                    <p class="p44">
                        <?php echo Auth::guard('web')->user()->info->description; ?>

                    </p>


                </div>


                <div class="experience4">
                    <h4>experience</h4>
                    <?php $__currentLoopData = Auth::guard('web')->user()->Experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="div-experience4">
                                    <span class="captalize4-span">
                                                                            <?php echo e($edu->name); ?>


                                    </span>
                            <span class="captalize4-span"><?php echo e($edu->company); ?> / <?php echo e(\Carbon\Carbon::parse($edu->start_date)->format('Y-m')); ?> - <?php echo e(\Carbon\Carbon::parse($edu->end_date)->format('Y-m')); ?></span>
                            <p class="p44"><?php echo e($edu->description); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="profile4 resume4-bottom">
                    <h4>Skills</h4>
                    <p class="p44">
                        <?php echo Auth::guard('web')->user()->info->description; ?>

                    </p>


                </div>
                <?php if(count(Auth::guard('web')->user()->Knows) >0): ?>

                    <div class="reference4">
                        <h4>reference</h4>
                        <div class="row">
                            <?php $__currentLoopData = Auth::guard('web')->user()->Knows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-6">
                                    <div class="border-reference reference4-lastspan ">
                                        <span>  company name : <?php echo e($edu->company); ?></span>
                                        <span class="p2-reference"> name :  <?php echo e($edu->name); ?></span>
                                        <span>
                                        job title : <?php echo e($edu->job_title); ?>

                                    </span>
                                        <span>
                                        phone  :<?php echo e($edu->phone); ?>

                                    </span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <?php endif; ?>
            </div>

        </div>
    </section>
</section>


<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.min.js"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>



<script src="<?php echo e(asset('website/assets/js/bootstrap.min.js')); ?>" ></script>





































</body>

</html>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/enpdfTemplates/template4.blade.php ENDPATH**/ ?>