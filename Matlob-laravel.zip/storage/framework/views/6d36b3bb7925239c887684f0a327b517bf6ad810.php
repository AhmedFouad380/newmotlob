<?php $__env->startSection('title'); ?>
    الوظائف
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css"
          integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <!-- this is content of company -->
    <section class="container container-space">
        <div class="row">
            <?php echo $__env->make('front.Company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-8">
                <!-- row -->
                <div class="col-md-12">
                    <div class="row jobs">
                        <div class="col-md-6">
                            <h5> الوظائف
                                <span>(<?php echo e($data->count()); ?>)</span>
                            </h5>
                        </div>
                        <div class="col-md-6 leftbtn">
                            <?php $companies = app('App\Models\Company'); ?>
                            <?php if(($companies->find(Auth::guard('company')->id())->company_type == 'private')): ?>
                            <?php if(\App\Models\CompanyPayment::where('company_id',Auth::guard('company')->id())->where('states','payed')->orderBy('id','desc')->first()
                            && \App\Models\CompanyPayment::where('company_id',Auth::guard('company')->id())->where('states','payed')->orderBy('id','desc')->first()->adv_count_used < \App\Models\CompanyPayment::where('company_id',Auth::guard('company')->id())->where('states','payed')->orderBy('id','desc')->first()->Package->adv_count  ): ?>
                                <a href="<?php echo e(url('AddJob')); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                    إضافة وظيفة جديدة
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(url('CompanyPackage')); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                    اشتارك في الباقة لاضافة وظيفة
                                </a>
                            <?php endif; ?>
                            <?php elseif(($companies->find(Auth::guard('company')->id())->company_type == 'employment')): ?>

                            <a href="<?php echo e(url('AddJob')); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                    إضافة وظيفة جديدة
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(url('CompanyPackage')); ?>" class="btn btn-primary">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                    اشتارك في الباقة لاضافة وظيفة
                                </a>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 col-12 new-job">
                        <div class="row center-jobss" style="padding: 10px;">
                            <div class="col-md-1 col-12">
                                <?php if(isset($job->Company->image)): ?>
                                    <img src="<?php echo e($job->Company->image); ?>" style="margin:5px; width:100px;height: 100px; border-radius: 50%;border: 2px #CCCCCC solid;" >
                                <?php else: ?>
                                    <i class="fa fa-briefcase bag-job" aria-hidden="true"></i>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-7 col-12">
                                <ul class="right-ul-jobs">
                                    <li class="li-1">
                                        <a  style="color:#4997D2"  href="<?php echo e(url('jobDetails',$job->id)); ?>">
                                            <?php echo e($job->title); ?>

                                        </a>
                                    </li>
                                    <li class="describe">
                                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                                        <?php echo e($job->Country->name); ?> - <?php echo e($job->City->name); ?>

                                    </li>
                                    <li class="li-2" >
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                        <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $job->created_at)->diffForHumans()); ?>

                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-12 job-flex-1 right-job-flex">
                                <ul class="job-flex" style="list-style:none">
                                    <div class="col-md-4 job-flex-1">
                                        <ul class="job-flex">
                                            <li class="li-3">
                                                <div>
                                                    <i class="fa fa-pencil-square-o" style="color:#4997D2"
                                                       aria-hidden="true"></i>
                                                    <br>
                                                    <a href="<?php echo e(url('edit-Job',$job->id)); ?>" class="edit">تعديل</a>
                                                </div>
                                            </li>
                                            <li class="li-4">
                                                <div>
                                                    <a href="<?php echo e(url('jobDetails',$job->id)); ?>" class="show">
                                                        <i class="fa fa-eye" style="color:#C3CCDC" aria-hidden="true"></i>
                                                        <br>
                                                        عرض
                                                    </a>
                                                </div>
                                            </li>
                                            <li class="li-4">
                                                <div>
                                                    <a href="<?php echo e(url('RepeatJob',$job->id)); ?>" class="green show">
                                                        <i class="fa fa-repeat" aria-hidden="true"></i>
                                                        <br>
                                                        نسخ
                                                    </a>
                                                </div>
                                            </li>

                                            <li class="li-4">
                                                <div>
                                                    <button data-id="<?php echo e($job->id); ?>" class="delete">
                                                        <i class="fa fa-trash-o" style="color:#D41111" aria-hidden="true"></i>
                                                        <br>
                                                        حذف
                                                    </button>
                                                </div>
                                            </li>


                                </ul>
                            </div>
                        </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <br>

                <div class="col-md-12">
                    <nav aria-label="Page navigation example">
                        <?php
                            $paginator =$data->appends(request()->input())->links()->paginator;
                                if ($paginator->currentPage() < 2 ){
                                            $link = $paginator->currentPage();
                                }else{
                                     $link = $paginator->currentPage() -1;
                                }
                                if($paginator->currentPage() == $paginator->lastPage()){
                                           $last_links = $paginator->currentPage();
                                }else{
                                           $last_links = $paginator->currentPage() +1;

                                }
                        ?>
                        <?php if($paginator->lastPage() > 1): ?>
                            <ul class="pagination">
                                <li class="<?php echo e(($paginator->currentPage() == 1) ? ' disabled' : ''); ?> page-item">
                                    <a class="page-link" href="<?php echo e($paginator->url(1)); ?>">الاول </a>
                                </li>
                                <?php for($i = $link; $i <= $last_links; $i++): ?>
                                    <li class="<?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?> page-item">
                                        <a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="<?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : ''); ?> page-item">
                                    <a class="page-link"
                                       href="<?php echo e($paginator->url($paginator->lastPage())); ?>">الاخير</a>
                                </li>
                            </ul>
                        <?php endif; ?>

                    </nav>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

        $(".delete").on("click", function () {
            var dataList = [];
            dataList.push($(this).data('id'));

            if (dataList.length > 0) {
                Swal.fire({
                    title: "تحذير.هل انت متأكد؟!",
                    text: "",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#f64e60",
                    confirmButtonText: "نعم",
                    cancelButtonText: "لا",
                    closeOnConfirm: false,
                    closeOnCancel: false
                }).then(function (result) {
                    if (result.value) {
                        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                        $.ajax({
                            url: '<?php echo e(url("delete-Job")); ?>',
                            type: "get",
                            data: {'id': dataList, _token: CSRF_TOKEN},
                            dataType: "JSON",
                            success: function (data) {
                                if (data.message == "Success") {
                                    $("input:checkbox:checked").parents("tr").remove();
                                    Swal.fire("نجاح", "تم الحذف بنجاح", "success");
                                    location.reload();
                                } else {
                                    Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                }
                            },
                            fail: function (xhrerrorThrown) {
                                Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                            }
                        });
                        // result.dismiss can be 'cancel', 'overlay',
                        // 'close', and 'timer'
                    } else if (result.dismiss === 'cancel') {
                        Swal.fire("ألغاء", "تم الالغاء", "error");
                    }
                });
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/Company/jobs.blade.php ENDPATH**/ ?>