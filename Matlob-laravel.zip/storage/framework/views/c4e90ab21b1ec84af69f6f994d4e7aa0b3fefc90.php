<div class="col-md-2">
    <ul class="company-data">
       <a href="<?php echo e(url('MyProfile')); ?>"><li <?php if(Request::segment(1) == 'MyProfile'): ?> class="blue gray first-li" <?php endif; ?> >الصفحة الشخصية</li></a>
        <a href="<?php echo e(url('MyJobs')); ?>"> <li <?php if(Request::segment(1) == 'MyJobs'): ?> class="blue gray " <?php endif; ?> >الوظائف</li></a>
    </ul>
</div>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/User/sidebar.blade.php ENDPATH**/ ?>