<?php $__env->startSection('title'); ?>
    انشاء السيرة الذاتية
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <!-- this is content -->

    <section class="container">
        <form method="post" action="<?php echo e(url('store-Organization')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row cv-maker">

                <div class="col-md-3 col-11 cv">
                    <div>
                        <h6>الشهادات و الدورات </h6>
                        <hr>
                        <ul class="ul">
                            <li class="green"><span class="green">1</span>  <a class="green" href="<?php echo e(url('cv-maker')); ?>">المعلومات الشخصية</a></li>
                            <li class="green"><span class="green">2</span> <a class="green" href="<?php echo e(url('cv-maker-step2')); ?>">الهدف المهني </a></li>
                            <li class="green"><span class=" green">3</span> <a  class="green"  href="<?php echo e(url('cv-maker-step2')); ?>">التعليم</a></li>
                            <li class="green"><span class="green ">4</span> <a class="green"  href="<?php echo e(url('cv-maker-step4')); ?>">الخبــرات </a></li>
                            <li class="green"><span class="green ">5</span> <a class="green"  href="<?php echo e(url('cv-maker-step5')); ?>"> المهــارات </a></li>
                            <li class="green"><span class="green ">6</span> <a class="green" href="<?php echo e(url('cv-maker-step6')); ?>">اللغات</a> </li>
                            <li class="green"><span class="green ">7</span> <a class="green" href="<?php echo e(url('cv-maker-step7')); ?>">المؤتمرات  و الدورات</a></li>
                            <li class="green"><span class="green ">8</span> <a class="green" href="<?php echo e(url('cv-maker-step8')); ?>">المعرفين</a></li>
                            <li class="blue"><span class="blue border-blue">9</span> <a class="blue" href="<?php echo e(url('cv-maker-step9')); ?>">المنظمات</a></li>
                            <li><span>10</span><a href="<?php echo e(url('cv-maker-step10')); ?>" >الخطوة النهــائية</a></li>
                        </ul>

                    </div>
                </div>

                <div class="col-md-8 col-11 cv-form">
                    <h5>المنظمات</h5>
                    <p>اضف عضويتك في المنظمات و النقابات و النوادي المهنية </p>
                    <div class="row">

                        <div class="form-group col-md-5 col-6">
                            <label> اسم المنظمة   </label>
                            <input type="text" class="form-control" required name="name" placeholder="اسم ">
                        </div>
                        <div class="form-group col-md-5 col-6">
                            <label> التاريخ</label>
                            <input type="date" class="form-control" name="date" placeholder="التاريخ">
                        </div>
                        <div class="form-group col-md-10 col-12">
                            <label> الدور  </label>
                            <input type="text" class="form-control" required name="job" placeholder="الدور ">
                        </div>
                        <div class="col-md-2 col-12">
                            <button type="submit" class="btn btn-primary btn-theme add" >
                                + إضافة
                            </button>

                        </div>

                    </div>
                </div>

                
                
                
                
                
                
                

                
                
                
                

                

                

            </div>
            <hr>
            <section >
                <div class="row">
                    <div class="col-md-3 none-div">
                    </div>
                    <div class="col-md-9 col-12">
                        <h5 style="font-weight: bolder">راجع المنظمات </h5>
                        <div class="row">
                            <?php $__currentLoopData = Auth::guard('web')->user()->Organization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 col-12">
                                    <div class="data">
                                        <?php echo e($key + 1); ?> . <?php echo e($data->name); ?>

                                        
                                        <i class="fa fa-trash-o delete" data-id="<?php echo e($data->id); ?>" aria-hidden="true"></i>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
            <hr>
            <div class="row">
                <div class="col-md-12 col-12">
                    <div class="btn-text">
                        <a type="button" class=" btn  btn-theme2" href="<?php echo e(url('cv-maker-step8')); ?>">
                            رجوع للخلف
                        </a>
                        <a href="<?php echo e(url('cv-maker-step10')); ?>" type="button" class="btn btn-primary btn-theme" >
                            الخطوة التالية
                        </a>
                    </div>
                </div>


            </div>
        </form>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

        $(".delete").on("click", function () {
            var dataList = $(this).data('id');

            if (dataList) {
                Swal.fire({
                    title: "تحذير.هل انت متأكد؟!",
                    text: "",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#f64e60",
                    confirmButtonText: "نعم",
                    cancelButtonText: "لا",
                    closeOnConfirm: false,
                    closeOnCancel: false
                }).then(function (result) {
                    if (result.value) {
                        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                        $.ajax({
                            url: '<?php echo e(url("delete-knows")); ?>',
                            type: "get",
                            data: {'id': dataList, _token: CSRF_TOKEN},
                            dataType: "JSON",
                            success: function (data) {
                                if (data.message == "Success") {
                                    $("input:checkbox:checked").parents("tr").remove();
                                    Swal.fire("نجاح", "تم الحذف بنجاح", "success");
                                    location.reload();
                                } else {
                                    Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                }
                            },
                            fail: function (xhrerrorThrown) {
                                Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                            }
                        });
                        // result.dismiss can be 'cancel', 'overlay',
                        // 'close', and 'timer'
                    } else if (result.dismiss === 'cancel') {
                        Swal.fire("ألغاء", "تم الالغاء", "error");
                    }
                });
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/cvmaker9.blade.php ENDPATH**/ ?>