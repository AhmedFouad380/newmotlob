<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/bootstrap.css')); ?>"  type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/all.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/cv.css')); ?>" type="text/css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.min.js"></script>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>

    <title>Template 2</title>

</head>

<body style="direction: ltr;">

<!--  this is resume 2  -->

<section class=" container a4-width" id="invoice" >
    <section class="row">
        <div class="col-md-4 col-4 change-row resume1-color">
            <div  id="sidebar" class="">
                <div class="center-cvimg">
                    <div class="img-size">
                        <img src="<?php echo e(Auth::guard('web')->user()->info->image); ?>">
                    </div>
                </div>
                <div class="resume1-about">
                    <h4>
                        <span class="i-color"><i class="fa fa-user" aria-hidden="true"></i></span>
                        About me
                    </h4>
                    <p><?php echo Auth::guard('web')->user()->info->description; ?></p>
                </div>
                <div class="contact">
                    <h4>Contacts</h4>
                    <div class="row">
                        <div class="col-md-2 col-2">
                            <div class="icon-blue">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <i class="fa fa-envelope icon-2" aria-hidden="true"></i>
                                <i class="fa fa-home" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="col-md-10 col-10 ">
                            <div>
                                <p class="p"><?php echo e(Auth::guard('web')->user()->info->phone); ?></p>
                                <p class="p"><?php echo e(Auth::guard('web')->user()->info->email); ?></p>
                                <p class="p"><?php echo e(Auth::guard('web')->user()->info->City->name); ?> -
                                    <?php echo e(Auth::guard('web')->user()->info->Country->name); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="education">
                    <h4>
                        <span class="i-color"><i class="fa fa-book" aria-hidden="true"></i></span>
                        Education
                    </h4>
                    <?php $__currentLoopData = Auth::guard('web')->user()->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="about-education">
                            <p class="resume-date">( <?php echo e(\Carbon\Carbon::parse($edu->graduation_date)->format('Y')); ?> )</p>
                            <p class="resume-dgree"><?php echo e($edu->name); ?></p>
                            <p class="resume-universtiy"><?php echo e($edu->qualification); ?> - <?php echo e($edu->area); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-8 col-8">
            <div class="left-space-cv">
                <div class="row">
                    <div class="col-md-11 col-11">
                        <div>
                            <h1>
                                <span class="color-h"><?php echo e(Auth::guard('web')->user()->info->firstname); ?></span>
                                <?php echo e(Auth::guard('web')->user()->info->lastname); ?>

                            </h1>
                            <span class="move-span"> <?php echo e(Auth::guard('web')->user()->info->job_title); ?></span>
                        </div>
                    </div>
                    <div class="col-md-1 col-1">
                        <div class="blue-div"></div>
                    </div>
                </div>
                <?php if(Auth::guard('web')->user()->Experience->count() > 0 ): ?>
                    <div class="experience">
                        <h4>Experience : </h4>
                        <?php $__currentLoopData = Auth::guard('web')->user()->Experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div>
                                <span class="uppercase-span">
                                    <?php echo e($edu->name); ?>

                                    <br>
                                    <b class="captalize-span"><?php echo e(\Carbon\Carbon::parse($edu->start_date)->format('Y-m')); ?> - <?php echo e(\Carbon\Carbon::parse($edu->end_date)->format('Y-m')); ?></b>
                                </span>
                                <span class="light-size"><?php echo e($edu->company); ?></span>
                                <p> <?php echo e($edu->description); ?>.</p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(Auth::guard('web')->user()->LangRelation->count() > 0 ): ?>
                    <div class="pro-skills">
                        <h4>Languages:</h4>
                        <div class="row">
                            <?php $lang = app('App\Models\Lang'); ?>

                            <?php $__currentLoopData = Auth::guard('web')->user()->LangRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="repeat">
                                    <div class="row">
                                        <div class="col-md-3 col-3">
                                            <h6><?php echo e($lang->find($edu->lang_id)->name); ?></h6>
                                        </div>
                                        <div class="col-md-9 col-9">
                                            <div class="progress-div">
                                                <div class="shape1">
                                                    <?php
                                                    if($edu->type == 'excellent'){
                                                        $value = '0px';

                                                    }elseif($edu->type == 'very_good'){
                                                        $value = '46px';
                                                    }elseif($edu->type == 'good'){
                                                        $value = '95px';
                                                    }else{
                                                        $value = '150px';
                                                    }
                                                    ?>

                                                    <div  class="shape2" style="left: <?php echo e($value); ?>!important;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php if(isset(Auth::guard('web')->user()->info->skills) ): ?>
                    <div class="interests">
                        <h4>Skills
                            :
                        </h4>
                        <div class="padding-interests">
                            <div class="row">
                                <div class="col-md-12 col-12">
                                    <p><?php echo Auth::guard('web')->user()->info->skills; ?></p>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(count(Auth::guard('web')->user()->Courses) >0): ?>
                    <div class="experience">
                        <h4>Conferences and courses</h4>
                        <?php $__currentLoopData = Auth::guard('web')->user()->Courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div>
                                <span class="uppercase-span">
                                    <?php if($edu->type == 'course '): ?> دورة <?php else: ?> مؤتمر  <?php endif; ?> : <?php echo e($edu->name); ?>

                                    <br>
                                    <b class="captalize-span"><?php echo e(\Carbon\Carbon::parse($edu->date)->format('Y-m')); ?></b>
                                </span>
                                <span class="light-size"><?php echo e($edu->company); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(count(Auth::guard('web')->user()->Knows) >0): ?>
                    <div class="interests">
                        <h4>Acquaintances
                            :
                        </h4>
                        <div class="padding-interests">
                            <div class="row">
                                <?php $__currentLoopData = Auth::guard('web')->user()->Knows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-md-6 col-6">
                                        <p>  اسم الشركة : <?php echo e($edu->company); ?></p>
                                        <p> الاسم :  <?php echo e($edu->name); ?></p>
                                        <p>
                                            المسمى الوظيفي : <?php echo e($edu->job_title); ?>

                                        </p>
                                        <p>
                                            رقم الهاتف  :<?php echo e($edu->phone); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                

            </div>
        </div>
    </section>
</section>



<script src="<?php echo e(asset('website/assets/js/bootstrap.min.js')); ?>" ></script>

<script>

    window.onload = function () {
        var HTML_Width = $("#invoice").width() - 200;
        var HTML_Height = $("#invoice").height();
        var top_left_margin = 10;
        var PDF_Width = HTML_Width+(top_left_margin*2);
        var PDF_Height = $('#sidebar').height()   ;

        var canvas_image_width = HTML_Width;
        var canvas_image_height = HTML_Height;


        var totalPDFPages = Math.ceil(HTML_Height/PDF_Height)-1;

        html2canvas($("#invoice")[0],{allowTaint:true}).then(function(canvas) {
            canvas.getContext('2d');

            var imgData = canvas.toDataURL("image/jpeg", 1.0);
            var pdf = new jsPDF("p", "pt",  [595.28, PDF_Height]);
            pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin,canvas_image_width,canvas_image_height);

            nextPage = PDF_Height + 30 ;
            for (var i = 1; i <= totalPDFPages; i++) {
                pdf.addPage(PDF_Width, PDF_Height);
                pdf.addImage(imgData, 'JPG', top_left_margin, -(nextPage*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
            }
            // pdf.save("CV.pdf");


        });
    };
</script>

</body>

</html>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/enpdfTemplates/template2.blade.php ENDPATH**/ ?>