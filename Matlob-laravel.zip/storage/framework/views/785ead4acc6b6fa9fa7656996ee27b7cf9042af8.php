<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        @media (min-width: 992px) {
            .aside-me .content {
                padding-right: 30px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h1 class="d-flex text-dark fw-bolder my-1 fs-3">تعديل بيانات الشركة</h1>
    <!--end::Title-->
    <!--begin::Breadcrumb-->
    <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-600">
            <a href="<?php echo e(url('/')); ?>" class="text-gray-600 text-hover-primary">لوحة القيادة</a>
        </li>
        <!--end::Item-->
        <!--begin::Item-->
        <li class="breadcrumb-item text-gray-500">قائمة الشركات</li>
        <li class="breadcrumb-item text-gray-500">تعديل بيانات الشركة</li>
        <!--end::Item-->
    </ul>
    <!--end::Breadcrumb-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
        <!--begin::Post-->

        <div class="content flex-row-fluid" id="kt_content">

            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                     data-bs-target="#kt_account_profile_details" aria-expanded="true"
                     aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">تعديل بيانات عميل</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_settings_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form id="kt_account_profile_details_form" action="<?php echo e(url('update-Companies')); ?>" class="form"
                          method="post">
                    <?php echo csrf_field(); ?>
                    <!--begin::Card body-->
                        <div class="card-body border-top p-9">
                            <!--begin::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">اسم الشركة</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="company_name"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="الاسم" value="<?php echo e($employee->company_name); ?>" required/>

                                <input type="hidden" name="id" value="<?php echo e($employee->id); ?>" required/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">الاسم الاول للمدير</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="first_name"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="الاسم" value="<?php echo e($employee->first_name); ?>" required/>

                                <input type="hidden" name="id" value="<?php echo e($employee->id); ?>" required/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">الاسم الثاني للمدير</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="last_name"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="الاسم" value="<?php echo e($employee->last_name); ?>" required/>

                                <input type="hidden" name="id" value="<?php echo e($employee->id); ?>" required/>
                                <!--end::Input-->
                            </div>











                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">البريد الالكترونى</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="email" name="email"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="البريد الالكتروني" value="<?php echo e($employee->email); ?>"
                                       required/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">رقم الهاتف</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="tel" name="phone"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="رقم الجوال" value="<?php echo e($employee->phone); ?>" required/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">كلمة المرور</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="password" name="password"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="كلمة المرور" value=""/>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">تأكيد كلمة المرور</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="password" name="password_confirmation"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="تأكيد كلمة المرور" value=""/>
                                <!--end::Input-->
                            </div>
                            <!--end::Input group-->
                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">النوع</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <select class="form-control" name="type">
                                    <option <?php if($employee->type == 'male'): ?> selected <?php endif; ?>  value="male" >ذكر</option>
                                    <option <?php if($employee->type == 'female'): ?> selected <?php endif; ?> value="female" >انثى</option>
                                </select>
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">القائم بعمليه التسجيل للباحث عن عمل</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <select class="form-control" name="how_register">
                                    <option  <?php if($employee->how_register == 'same'): ?> selected <?php endif; ?> value="same" >نفسه</option>
                                    <option  <?php if($employee->how_register == 'brother'): ?> selected <?php endif; ?> value="brother" >الاخ</option>
                                    <option  <?php if($employee->how_register == 'sister'): ?>  selected <?php endif; ?> value="sister" >الاخت</option>
                                    <option <?php if($employee->how_register == 'father'): ?>  selected <?php endif; ?>  value="father" >الاب</option>
                                    <option <?php if($employee->how_register == 'mother'): ?>  selected <?php endif; ?>  value="mother" >الام</option>
                                    <option <?php if($employee->how_register == 'friend'): ?>  selected <?php endif; ?>  value="friend" >صديق</option>
                                    <option <?php if($employee->how_register == 'near'): ?>  selected <?php endif; ?>  value="near" >قريب</option>
                                </select>
                                <!--end::Input-->
                            </div>

                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <label for="exampleFormControlInput1"
                                       class="form-label">الدولة</label>
                                <select class="form-control form-control-solid mb-3 mb-lg-0"
                                        name="country_id" aria-label="" required id="country2">
                                    <option value="">اختر الدولة</option>
                                    <?php $__currentLoopData = \App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->country_id == $state->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <!--end::Input group-->

                            <div class="fv-row mb-7">
                                <label for="exampleFormControlInput1"
                                       class="form-label">المحاقظة</label>
                                <select class="form-control form-control-solid mb-3 mb-lg-0"
                                        name="city_id" aria-label="" required id="city2">
                                    <option value="">اختر المحاقظة</option>
                                    <option selected
                                            value="<?php echo e($employee->City->id); ?>"><?php echo e($employee->City->name); ?></option>

                                </select>
                            </div>
                            <div class="fv-row mb-7">
                                <label for="exampleFormControlInput1"
                                       class="form-label">المنطقة</label>
                                <select class="form-control form-control-solid mb-3 mb-lg-0"
                                        name="state_id" aria-label="" required id="state2">
                                    <option value="">اختر المنظقة</option>
                                    <option selected
                                            value="<?php echo e($employee->State->id); ?>"><?php echo e($employee->State->name); ?></option>

                                </select>
                            </div>

                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">رقم البطاقه الضريبيه</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="tax_card_number"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="رقم الجوال" value="<?php echo e($employee->tax_card_number); ?>" />
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <!--begin::Label-->
                                <label class="required fw-bold fs-6 mb-2">رقم البطاقه الضريبيه</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <input type="text" name="commercial_registration_number"
                                       class="form-control form-control-solid mb-3 mb-lg-0"
                                       placeholder="رقم الجوال" value="<?php echo e($employee->commercial_registration_number); ?>" />
                                <!--end::Input-->
                            </div>
                            <div class="fv-row mb-7">
                                <label>صورة السجل الضريبية</label>
                                <input type="file"   name="tax_card_image" class="form-control">
                                <a href="<?php echo e($employee->tax_card_image); ?>" class="btn btn-success">تحميل</a>
                            </div>
                            <div class="fv-row mb-7">
                                <label>صورة السجل التجاري</label>
                                <input type="file"   name="commercial_registration_image" class="form-control">
                                <a href="<?php echo e($employee->commercial_registration_image); ?>" class="btn btn-success">تحميل</a>

                            </div>
                            <div class="fv-row mb-7">
                                <label>اتفاقية التوظيف</label>
                                <input type="file"   name="employment_agreement_user" class="form-control">
                                <a href="<?php echo e($employee->employment_agreement_user); ?>" class="btn btn-success">تحميل</a>

                            </div>
                            <div class="fv-row mb-7">
                                <label>خطاب التحقق</label>
                                <input type="file"   name="verification_letter_image_user" class="form-control">
                                <a href="<?php echo e($employee->employment_agreement); ?>" class="btn btn-success">تحميل</a>

                            </div>
                                <!--begin::Label-->

                            <!--end::Input group-->
                            <div class="fv-row mb-7">
                                <div
                                    class="form-check form-switch form-check-custom form-check-solid">
                                    <label class="form-check-label" for="flexSwitchDefault">مفعل
                                        ؟</label>
                                    <input class="form-check-input" name="is_active" type="hidden"
                                           value="inactive" id="flexSwitchDefault"/>
                                    <input class="form-check-input form-control form-control-solid mb-3 mb-lg-0"
                                           name="is_active" type="checkbox"
                                           value="active" id="flexSwitchDefault"
                                           <?php if($employee->is_active == 'active'): ?> checked <?php endif; ?> />
                                </div>
                            </div>
                            <!--end::Input group-->


                        </div>
                        <!--end::Scroll-->
                        <!--begin::Actions-->

                        <div class="card-footer d-flex justify-content-end py-6 px-9">
                            <button type="reset" class="btn btn-light btn-active-light-primary me-2">الغاء</button>
                            <button type="submit" class="btn btn-primary" id="kt_account_profile_details_submit">حفظ
                            </button>
                        </div>
                        <!--end::Actions-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->

        </div>
        <!--end::Post-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>

        $("#city2").on('click , change',function () {
            var wahda = $(this).val();

            if (wahda != '') {
                $.get("<?php echo e(URL::to('/getState')); ?>" + '/' + wahda, function ($data) {
                    $('#state2').html($data);
                });
            }
        });

        $("#country2").on('click , change',function () {
            var wahda = $(this).val();

            if (wahda != '') {
                $.get("<?php echo e(URL::to('/get-Cities')); ?>" + '/' + wahda, function ($data) {
                    $('#city2').html($data);
                });
            }
        });
    </script>


    <?php
    $message = session()->get("message");
    ?>
    <?php if( session()->has("message")): ?>
        <script>
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": true,
                "progressBar": true,
                "positionClass": "toast-bottom-right",
                "preventDuplicates": false,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
            toastr.success("نجاح", "<?php echo e($message); ?>");
        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/admin/Company/edit.blade.php ENDPATH**/ ?>