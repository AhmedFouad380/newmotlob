<div class="col-md-2">
    <ul class="company-data">
       <a href="<?php echo e(url('Profile')); ?>"><li <?php if(Request::segment(1) == 'Profile'): ?> class="blue gray first-li" <?php endif; ?> >حساب الشركة</li></a>
        <a href="<?php echo e(url('Company-jobs')); ?>"> <li <?php if(Request::segment(1) == 'Company-jobs'): ?> class="blue gray " <?php endif; ?> >الوظائف</li></a>
        <?php $companies = app('App\Models\Company'); ?>
        <?php if(($companies->find(Auth::guard('company')->id())->company_type == 'employment')): ?>
        <a href="<?php echo e(url('Reports')); ?>">  <li  <?php if(Request::segment(1) == 'Reports'): ?> class="blue gray " <?php endif; ?> >التقارير
            </li></a>
        <a href="<?php echo e(url('MyInvoices')); ?>"><li <?php if(Request::segment(1) == 'MyInvoices' || Request::segment(1) =='InvoiceDetail'): ?> class="blue gray " <?php endif; ?>>
            الحسابات



        </li>
        </a>

            <a href="<?php echo e(url('Complaints')); ?>">  <li  <?php if(Request::segment(1) == 'Complaints'): ?> class="blue gray " <?php endif; ?>  >الشكاوي</li></a>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/Company/sidebar.blade.php ENDPATH**/ ?>