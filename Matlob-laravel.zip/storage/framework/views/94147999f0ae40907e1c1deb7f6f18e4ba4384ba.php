<script>var hostUrl = "<?php echo e(asset('admin/assets/')); ?>";</script>
<!--begin::Javascript-->
<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="<?php echo e(asset('admin/assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/scripts.bundle.js')); ?>"></script>
<!--end::Global Javascript Bundle-->
<!--begin::Page Custom Javascript(used by this page)-->
<?php echo $__env->yieldContent('script'); ?>
<!--end::Page Custom Javascript-->

<?php
$errors = session()->get("errors");
?>

<?php if( session()->has("errors")): ?>
    <?php
    $e = implode(' - ', $errors->all());
    ?>

    <script>
        Swal.fire({
            icon: 'warning',
            title: "برجاء التأكد من البيانات.",
            text: "<?php echo e($e); ?> ",
            type: "error",
            timer: 5000,
            showConfirmButton: false
        });
    </script>

<?php endif; ?>


<?php if( session()->has("error")): ?>
    <?php
    $e = session()->get("error");
    ?>

    <script>
        Swal.fire({
            icon: 'warning',
            title: "برجاء التأكد من البيانات.",
            text: "<?php echo e($e); ?> ",
            type: "error",
            timer: 5000,
            showConfirmButton: false
        });
    </script>

<?php endif; ?>
<?php
$error_message = session()->get("error_message");
?>

<?php if( session()->has("error_message")): ?>
    <script>
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-bottom-right",
            "preventDuplicates": false,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };

        toastr.error("<?php echo e($error_message); ?>" , "عفوا !" );
    </script>

<?php endif; ?>

<!--end::Javascript-->

<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/admin/layouts/footer-script.blade.php ENDPATH**/ ?>