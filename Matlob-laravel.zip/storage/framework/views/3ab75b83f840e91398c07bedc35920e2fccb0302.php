<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/bootstrap.css')); ?>"  type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/all.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('website/assets/css/cv.css')); ?>" type="text/css">
    <title>مطلوب || سيرة ذاتية</title>

</head>

<body style="direction: ltr;" onload="window.print()">

<!--  this is resume 3  -->

<section class=" container a4-width3">
    <div class="resume3-top">
        <section class="row">
            <div class="col-md-4 col-4">
                <div class="img-resume3">
                    <?php if(isset(Auth::guard('web')->user()->info->image)): ?>
                        <img src="<?php echo e(Auth::guard('web')->user()->info->image); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('website/assets/images/Rectangle 1 copy.png')); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-5 col-5">
                <div class="resume3-info1">
                    <h2>                                <?php echo e(Auth::guard('web')->user()->info->firstname); ?>

                        <span class="name-span">   <?php echo e(Auth::guard('web')->user()->info->lastname); ?> </span></h2>
                    <span class="block-span-resume3">                                <?php echo e(Auth::guard('web')->user()->info->job_title); ?>

</span>
                        <?php echo Auth::guard('web')->user()->info->description; ?>


                </div>
            </div>
            <div class="col-md-3 col-3">
                <div class="data-resume3">
                    <div class="adress">
                        <h6>adress</h6>
                        <p><?php echo e(Auth::guard('web')->user()->info->City->name); ?> -
                            <?php echo e(Auth::guard('web')->user()->info->Country->name); ?></p>
                    </div>
                    <div class="phone">
                        <h6>phone</h6>
                        <p><?php echo e(Auth::guard('web')->user()->info->phone); ?></p>
                    </div>
                    <div class="email">
                        <h6>email</h6>
                        <p><?php echo e(Auth::guard('web')->user()->info->email); ?></p>
                    </div>

                </div>
            </div>
        </section>
    </div>
    <section class="row">
        <siction class="col-md-8 col-8">
            <div class="parent-divs">
                <div class="work-experience">
                    <h4>work experience</h4>
                    <?php $__currentLoopData = Auth::guard('web')->user()->Experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class=" experience-resume3">
                        <div class="row">
                            <div class="col-md-3 col-3">
                                <div><?php echo e(\Carbon\Carbon::parse($edu->start_date)->format('Y-m')); ?> - <?php echo e(\Carbon\Carbon::parse($edu->end_date)->format('Y-m')); ?></div>
                            </div>
                            <div class="col-md-9 col-9">
                                <div>
                                    <h6 class="H6"> <?php echo e($edu->name); ?></h6>
                                    <h6 Class="Hh6"><?php echo e($edu->company); ?></h6>
                                    <p><?php echo e($edu->description); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            <div class="work-experience">
                <h4>Skills</h4>
                <?php $__currentLoopData = Auth::guard('web')->user()->Experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class=" experience-resume3">
                        <div class="row">
                        <div class="col-md-9 col-9">
                            <div>
                                <h6 class="H6">                         <?php echo Auth::guard('web')->user()->info->description; ?>

                                </h6>
                            </div>
                        </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php if(count(Auth::guard('web')->user()->Knows) >0): ?>

            <div class="work-experience">
                <h4> reference
                </h4>
                <?php $__currentLoopData = Auth::guard('web')->user()->Knows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div class=" experience-resume3">
                        <div class="row">

                        <div class="col-md-9 col-9">
                            <div>
                                <h6 class="H6"> Name: <?php echo e($edu->name); ?></h6>
                                <h6 Class="H6">  company name : <?php echo e($edu->company); ?></h6>
                                <h6 Class="H6"> <?php echo e($edu->description); ?>

                                </h6>
                                <h6 Class="H6">  job title : <?php echo e($edu->job_title); ?>

                                </h6>
                                <h6 Class="H6">   phone  :<?php echo e($edu->phone); ?>

                                </h6>
                            </div>
                        </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php endif; ?>


            </div>
        </siction>
        <section class="col-md-4 col-4">
            <div class="pesronal-data">
                <div class="education3">
                    <h4>education</h4>
                    <?php $__currentLoopData = Auth::guard('web')->user()->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="enter-major">
                        <h6><?php echo e($edu->qualification); ?> </h6>
                        <p><?php echo e($edu->name); ?>

                        </p>
                        <span>( <?php echo e(\Carbon\Carbon::parse($edu->graduation_date)->format('Y')); ?> )</span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="preference3">
                    <h4>Languages</h4>
                    <?php $lang = app('App\Models\Lang'); ?>
                    <?php $__currentLoopData = Auth::guard('web')->user()->LangRelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="preference3-data">
                        <h6><?php echo e($lang->find($edu->lang_id)->name); ?></h6>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <div class="hobbies">
                    <h4>Organization</h4>
                    <div class="row">
                        <?php $__currentLoopData = Auth::guard('web')->user()->Organization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-4 col-md-4">
                            <div><?php echo e($edu->name); ?></div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </div>
            </div>
        </section>

    </section>
</section>




</body>

</html>
<?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/enpdfTemplates/template5.blade.php ENDPATH**/ ?>