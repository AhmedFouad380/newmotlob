<?php $__env->startSection('title'); ?>
    انشاء السيرة الذاتية
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <!-- this is content -->

    <section class="container">
        <form method="post" action="<?php echo e(url('store-Course')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row cv-maker">

                <div class="col-md-3 col-11 cv">
                    <div>
                        <h6>الشهادات و الدورات </h6>
                        <hr>
                        <ul class="ul">
                            <li class="green"><span class="green">1</span>  <a class="green" href="<?php echo e(url('cv-maker')); ?>">المعلومات الشخصية</a></li>
                            <li class="green"><span class="green">2</span> <a class="green" href="<?php echo e(url('cv-maker-step2')); ?>">الهدف المهني </a></li>
                            <li class="green"><span class=" green">3</span> <a  class="green"  href="<?php echo e(url('cv-maker-step2')); ?>">التعليم</a></li>
                            <li class="green"><span class="green ">4</span> <a class="green"  href="<?php echo e(url('cv-maker-step4')); ?>">الخبــرات </a></li>
                            <li class="green"><span class="green ">5</span> <a class="green"  href="<?php echo e(url('cv-maker-step5')); ?>"> المهــارات </a></li>
                            <li class="green"><span class="green ">6</span> <a class="green" href="<?php echo e(url('cv-maker-step6')); ?>">اللغات</a> </li>
                            <li class="blue"><span class="blue border-blue">7</span> <a class="blue" href="<?php echo e(url('cv-maker-step7')); ?>">المؤتمرات  و الدورات</a></li>
                            <li><span>8</span><a href="<?php echo e(url('cv-maker-step8')); ?>">المعرفين</a></li>
                            <li><span>9</span><a href="<?php echo e(url('cv-maker-step9')); ?>">المنظمات</a></li>
                            <li><span>10</span><a href="<?php echo e(url('cv-maker-step10')); ?>" >الخطوة النهــائية</a></li>
                        </ul>

                    </div>
                </div>

                <div class="col-md-8 col-11 cv-form">
                    <h5>المؤتمرات و الدورات</h5>
                    <p>أضف الادورات او المؤتمرات </p>
                    <div class="row">
                        <div class="form-group col-md-6 col-6">
                            <label> النوع  </label>
                            <select class="form-control" required name="type">
                                <option value="course">دورة</option>
                                <option value="event">مؤتمر</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6 col-6">
                            <label> الاسم  </label>
                            <input type="text" class="form-control" required name="name" placeholder="اسم ">
                        </div>

                        <div class="form-group col-md-6 col-6">
                            <label> الشركة</label>
                            <input type="text" class="form-control" name="company" placeholder="اسم الشركة">
                        </div>
                        <div class="form-group col-md-6 col-6">
                            <label>التاريخ </label>
                            <input type="date" class="form-control" required name="date" placeholder="التاريخ">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 col-6">
                            <label> رابط الملف </label>
                            <input type="text" class="form-control" name="link">
                        </div>
                        <div class="form-group col-md-4 col-6">
                            <label> رفع الملف </label>
                            <input type="file" class="form-control" name="file">
                        </div>
                        <button type="submit" class="btn btn-primary btn-theme add" >
                            + إضافة
                        </button>
                    </div>
                </div>

                
                
                
                
                
                
                

                
                
                
                

                

                

            </div>
            <hr>
            <section >
                <div class="row">
                    <div class="col-md-3 none-div">
                    </div>
                    <div class="col-md-9 col-11">
                        <h5 style="font-weight: bolder">راجع شهادتك الدراسية</h5>
                        <div class="row">
                            <?php $__currentLoopData = Auth::guard('web')->user()->Courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 col-12">
                                    <div class="data">
                                        <i class="fa fa-trash-o delete" data-id="<?php echo e($data->id); ?>" aria-hidden="true"></i>
                                        <?php echo e($key + 1); ?> . <?php echo e($data->name); ?>  <br>
                                        شركة : <?php echo e($data->company); ?> <br>
                                        التاريخ : <?php echo e(\Carbon\Carbon::parse($data->date)->format('Y-m')); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
            <hr>
            <div class="row">
                <div class="col-md-12 col-11">
                    <div class="btn-text">
                        <a type="button" class=" btn  btn-theme2" href="<?php echo e(url('cv-maker-step6')); ?>">
                            رجوع للخلف
                        </a>
                        <a href="<?php echo e(url('cv-maker-step8')); ?>" type="button" class="btn btn-primary btn-theme" >
                            الخطوة التالية
                        </a>

                    </div>
                </div>


            </div>
        </form>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

        $(".delete").on("click", function () {
            var dataList = $(this).data('id');

            if (dataList) {
                Swal.fire({
                    title: "تحذير.هل انت متأكد؟!",
                    text: "",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#f64e60",
                    confirmButtonText: "نعم",
                    cancelButtonText: "لا",
                    closeOnConfirm: false,
                    closeOnCancel: false
                }).then(function (result) {
                    if (result.value) {
                        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                        $.ajax({
                            url: '<?php echo e(url("delete-Course")); ?>',
                            type: "get",
                            data: {'id': dataList, _token: CSRF_TOKEN},
                            dataType: "JSON",
                            success: function (data) {
                                if (data.message == "Success") {
                                    $("input:checkbox:checked").parents("tr").remove();
                                    Swal.fire("نجاح", "تم الحذف بنجاح", "success");
                                    location.reload();
                                } else {
                                    Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                }
                            },
                            fail: function (xhrerrorThrown) {
                                Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                            }
                        });
                        // result.dismiss can be 'cancel', 'overlay',
                        // 'close', and 'timer'
                    } else if (result.dismiss === 'cancel') {
                        Swal.fire("ألغاء", "تم الالغاء", "error");
                    }
                });
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/cvmaker7.blade.php ENDPATH**/ ?>