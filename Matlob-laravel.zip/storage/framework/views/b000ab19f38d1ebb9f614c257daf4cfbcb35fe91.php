<link rel="shortcut icon" href="assets/media/logos/favicon.ico" />
<!--begin::Fonts-->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
<!--end::Fonts-->
<!--begin::Page Vendor Stylesheets(used by this page)-->
<?php echo $__env->yieldContent('css'); ?>
<!--end::Page Vendor Stylesheets-->
<!--begin::Global Stylesheets Bundle(used by all pages)-->
<link href="<?php echo e(asset('admin/assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('admin/assets/css/style.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css" />
<!--end::Global Stylesheets Bundle-->
<?php echo $__env->yieldContent('style'); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/admin/layouts/head.blade.php ENDPATH**/ ?>