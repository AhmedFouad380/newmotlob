<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <style>
        .noneopacity{
            opacity: unset!important;
        }
        .nav-link{
            opacity: .5;
        }
        td{
            font-size:16px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="container job-width">
        <div class="row">
            <div class="col-md-12 jobb-border">
                <div class="row take-space control-1">
                    <div class="col-md-6 flex-h6">
                        <h6>
                            <i class="fa fa-list" aria-hidden="true"></i>
                            اختيار نوع الشركة
                        </h6>
                    </div>

                </div>
            </div>
            <div class="col-md-12 job-border">
                <div class="row take-space ">
                    <div class="container col-md-12 control-tab ">
                        
                        
                        
                        
                        
                        

                        <div class="control-2">
                            <ul class="nav nav-tabs" id="myTab" role="tablist" style="border-radius: 5px">
                                <li class="nav-item" role="presentation">
                                    <button class=" item-border nav-link noneopacity active" id="home-tab" data-bs-toggle="tab" data-bs-target="#private" type="button" role="tab" aria-controls="home" aria-selected="true">
                                        <br>
                                        <span class="black-span"></span>
                                        <p>باقة الشركات الخاصة  </p>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="item-border nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#employment" type="button" role="tab" aria-controls="profile" aria-selected="false">
                                        <br>
                                        <span class="black-span"></span>
                                        <p>باقة شركات التوظيف </p>
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="private" role="tabpanel" aria-labelledby="home-tab">
                                <div class="container col-md-12 control-tab ">
                                    
                                    
                                    
                                    
                                    
                                    

                                    <div class="control-2">
                                        <ul class="nav nav-tabs" id="myTab" role="tablist" style="border-radius: 5px">
                                            <li class="nav-item" role="presentation">
                                                <button class=" item-border nav-link noneopacity active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">
                                                    <br>
                                                    <span class="black-span"></span>
                                                    <p> اسعار 3 شهور</p>
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="item-border nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#home2" type="button" role="tab" aria-controls="profile" aria-selected="false">
                                                    <br>
                                                    <span class="black-span"></span>
                                                    <p> اسعار 6 شهور</p>
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="item-border nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#home3" type="button" role="tab" aria-controls="profile" aria-selected="false">
                                                    <br>
                                                    <span class="red-span"></span>
                                                    <p> اسعار 9 شهور</p>
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class=" item-border nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#home4" type="button" role="tab" aria-controls="contact" aria-selected="false">
                                                    <br>
                                                    <span class="green-span"></span>
                                                    <p> اسعار 12 شهر</p>
                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                            <form>
                                                <section class="container">

                                                    <section class="cv-offer-center">
                                                        <?php $__currentLoopData = \App\Models\CompanyPackage::where('is_active','active')->where('months','3')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div >

                                                                <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                    light
<?php endif; ?>
                                                                    ">
                                                                    <h6><?php echo e($Package->title); ?></h6>
                                                                    <br>
                                                                    <p class="cv-1">
                                                                        <?php echo e($Package->description); ?>

                                                                    </p>
                                                                    <h1><?php echo e($Package->price); ?></h1>
                                                                    <p class="cv-1">جنيه مصري</p>

                                                                    <p class="p-cv3">
                                                                        <a  class="btn <?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                            light
<?php endif; ?> " style="text-decoration: none" href="<?php echo e(url('PaymentPackage',$Package->id)); ?>">
                                                                            <i class="fa fa-shopping-cart"></i>
                                                                            اطلب الان

                                                                        </a>
                                                                    </p>
                                                                </div>
                                                                <div style="width:200px!important; font-size: 12px">
                                                                    <hr>
                                                                    <p >
                                                                        <?php echo $Package->long_description; ?>

                                                                    </p>
                                                                </div>
                                                            </div>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </section>
                                                    <hr class="offer-line">
                                                </section>
                                            </form>
                                        </div>
                                        <div class="tab-pane fade" id="home2" role="tabpanel" aria-labelledby="profile-tab">
                                            <form>
                                                <section class="container">


                                                    <section class="cv-offer-center">
                                                        <?php $__currentLoopData = \App\Models\CompanyPackage::where('is_active','active')->where('months','6')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div >

                                                                <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                    light
<?php endif; ?>
                                                                    ">
                                                                    <h6><?php echo e($Package->title); ?></h6>
                                                                    <br>
                                                                    <p class="cv-1">
                                                                        <?php echo e($Package->description); ?>

                                                                    </p>
                                                                    <h1><?php echo e($Package->price); ?></h1>
                                                                    <p class="cv-1">جنيه مصري</p>

                                                                    <p class="p-cv3">
                                                                        <a  class="btn <?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                            light
<?php endif; ?> " style="text-decoration: none" href="<?php echo e(url('PaymentPackage',$Package->id)); ?>">
                                                                            <i class="fa fa-shopping-cart"></i>
                                                                            اطلب الان

                                                                        </a>
                                                                    </p>
                                                                </div>
                                                                <div style="width:200px!important; font-size: 12px">
                                                                    <hr>
                                                                    <p >
                                                                        <?php echo $Package->long_description; ?>

                                                                    </p>
                                                                </div>
                                                            </div>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </section>
                                                    <hr class="offer-line">
                                                </section>
                                            </form>

                                        </div>
                                        <div class="tab-pane fade" id="home3" role="tabpanel" aria-labelledby="contact-tab">
                                            <form>
                                                <section class="container">

                                                    <section class="cv-offer-center">
                                                        <?php $__currentLoopData = \App\Models\CompanyPackage::where('is_active','active')->where('months','9')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div >

                                                                <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                    light
<?php endif; ?>
                                                                    ">
                                                                    <h6><?php echo e($Package->title); ?></h6>
                                                                    <br>
                                                                    <p class="cv-1">
                                                                        <?php echo e($Package->description); ?>

                                                                    </p>
                                                                    <h1><?php echo e($Package->price); ?></h1>
                                                                    <p class="cv-1">جنيه مصري</p>

                                                                    <p class="p-cv3">
                                                                        <a  class="btn <?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                            light
<?php endif; ?> " style="text-decoration: none" href="<?php echo e(url('PaymentPackage',$Package->id)); ?>">
                                                                            <i class="fa fa-shopping-cart"></i>
                                                                            اطلب الان

                                                                        </a>
                                                                    </p>
                                                                </div>
                                                                <div style="width:200px!important; font-size: 12px">
                                                                    <hr>
                                                                    <p >
                                                                        <?php echo $Package->long_description; ?>

                                                                    </p>
                                                                </div>
                                                            </div>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </section>
                                                    <hr class="offer-line">
                                                </section>
                                            </form>

                                        </div>
                                        <div class="tab-pane fade" id="home4" role="tabpanel" aria-labelledby="contact-tab">
                                            <form>
                                                <section class="container">

                                                    <section class="cv-offer-center">
                                                        <?php $__currentLoopData = \App\Models\CompanyPackage::where('is_active','active')->where('months','12')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div >

                                                                <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                    light
<?php endif; ?>
                                                                    ">
                                                                    <h6><?php echo e($Package->title); ?></h6>
                                                                    <br>
                                                                    <p class="cv-1">
                                                                        <?php echo e($Package->description); ?>

                                                                    </p>
                                                                    <h1><?php echo e($Package->price); ?></h1>
                                                                    <p class="cv-1">جنيه مصري</p>

                                                                    <p class="p-cv3">
                                                                        <a  class="btn <?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                            light
<?php endif; ?> " style="text-decoration: none" href="<?php echo e(url('PaymentPackage',$Package->id)); ?>">
                                                                            <i class="fa fa-shopping-cart"></i>
                                                                            اطلب الان

                                                                        </a>
                                                                    </p>
                                                                </div>
                                                                <div style="width:200px!important; font-size: 12px">
                                                                    <hr>
                                                                    <p >
                                                                        <?php echo $Package->long_description; ?>

                                                                    </p>
                                                                </div>
                                                            </div>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </section>
                                                    <hr class="offer-line">
                                                </section>
                                            </form>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="employment" role="tabpanel" aria-labelledby="profile-tab">
                                <form>
                                    <section class="container">


                                        <section class="cv-offer-center">
                                            <?php $__currentLoopData = \App\Models\CompanyPackage::where('is_active','active')->where('months','6')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div >

                                                    <div class="<?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                        light
<?php endif; ?>
                                                        ">
                                                        <h6><?php echo e($Package->title); ?></h6>
                                                        <br>
                                                        <p class="cv-1">
                                                            <?php echo e($Package->description); ?>

                                                        </p>
                                                        <h1><?php echo e($Package->price); ?></h1>
                                                        <p class="cv-1">جنيه مصري</p>

                                                        <p class="p-cv3">
                                                            <a  class="btn <?php if($Package->color == 'wight'): ?> light
                    <?php elseif($Package->color == 'blue'): ?>  platinum
                    <?php elseif($Package->color == 'green'): ?> silver
                    <?php elseif($Package->color == 'blue'): ?>gold
                    <?php else: ?>
                                                                light
<?php endif; ?> " style="text-decoration: none" href="<?php echo e(url('PaymentPackage',$Package->id)); ?>">
                                                                <i class="fa fa-shopping-cart"></i>
                                                                اطلب الان

                                                            </a>
                                                        </p>
                                                    </div>
                                                    <div style="width:200px!important; font-size: 12px">
                                                        <hr>
                                                        <p >
                                                            <?php echo $Package->long_description; ?>

                                                        </p>
                                                    </div>
                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </section>
                                        <hr class="offer-line">
                                    </section>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script>

        $('.nav-link').click(function(){
            $('.nav-link').removeClass('noneopacity');
            $(this).addClass('noneopacity')
            var value = $(this).data('bs-target');
            $('.tab-pane').removeClass('show');
            $('.tab-pane').removeClass('active');
            $(value).addClass(' show active');
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/Company/packagetype.blade.php ENDPATH**/ ?>