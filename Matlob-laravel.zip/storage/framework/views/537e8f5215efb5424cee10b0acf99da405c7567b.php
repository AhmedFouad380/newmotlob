<?php $__env->startSection('title'); ?>
    <?php echo e($data->title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- this is content -->

    <section class="container">
        <div class="row cv-maker">
            <h2>    <?php echo e($data->title); ?>

            </h2>
            <div class="col-md-8">
            <?php echo $data->description; ?>

            </div>
            <div class="col-md-4">
                <img src="<?php echo e(asset($data->image)); ?>" class="page-image">
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Matlob-laravel\resources\views/front/Page.blade.php ENDPATH**/ ?>