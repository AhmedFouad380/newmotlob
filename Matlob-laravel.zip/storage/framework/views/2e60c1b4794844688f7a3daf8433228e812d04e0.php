<?php $__env->startSection('title'); ?>
    الاسئلة الشائعة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .Que{
            display: none;
        }
        .active-Que{
            display: block!important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="container">
    <section class="row tab-header ">
        <div class="col-md-12">
            <img src="<?php echo e(asset('website/assets/images/logo.png')); ?>" class="logo-header">
        </div>
        <div class="col-md-12 title-header"> الأسئـلة الشائـعة</div>
    </section>
</section>
<!-- start tab -->
<section class="container">
    <ul class="nav nav-tabs faq-tabs" id="myTab" role="tablist">
        <li class=" faq-tab" role="presentation">
            <button class="nav-link faq-button active item active-item" data-id="home-tab" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">الباحث عن العمل</button>
        </li>
        <li class=" faq-tab" role="presentation">
            <button class="nav-link item  faq-button"  id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">الرسوم</button>
        </li>
        <li class=" faq-tab" role="presentation">
            <button class="nav-link item  faq-button" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">الشركات</button>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <!-- collapse item 1 -->
            <div id="accordion">
                <?php
                $active = 'show';
                ?>
                <?php $__currentLoopData = \App\Models\Faq::where('is_active','active')->where('type','works')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0"> <?php echo e($faq->title); ?>

                                <button class="btn btn-link button-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapseOne">
                                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseOne<?php echo e($key); ?>" class="collapse <?php echo e($active); ?>" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="card-body">
                                <?php echo e($faq->description); ?>

                            </div>
                        </div>
                    </div>

                    <?php
                    $active = '';
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <div id="accordion">
                <?php
                $active = 'show';
                ?>
                <?php $__currentLoopData = \App\Models\Faq::where('is_active','active')->where('type','payment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0"> <?php echo e($faq->title); ?>

                                <button class="btn btn-link button-link" data-toggle="collapse" data-target="#collapsetow<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapseOne">
                                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapsetow<?php echo e($key); ?>" class="collapse <?php echo e($active); ?>" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="card-body">
                                <?php echo e($faq->description); ?>

                            </div>
                        </div>
                    </div>

                    <?php
                    $active = '';
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            </div>
        </div>
        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
            <div id="accordion">
                <?php
                $active = 'show';
                $icon = '<i class="fa fa-plus-circle" aria-hidden="true"></i>';
                ?>
                <?php $__currentLoopData = \App\Models\Faq::where('is_active','active')->where('type','companies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0"> <?php echo e($faq->title); ?>

                                <button class="btn btn-link button-link" data-toggle="collapse" data-target="#collapseAt<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapseOne">
                                    <i class="fa fa-minus-circle" aria-hidden="true"></i>
                                </button>
                            </h5>
                        </div>
                        <div id="collapseAt<?php echo e($key); ?>" class="collapse <?php echo e($active); ?>" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="card-body">
                                <?php echo e($faq->description); ?>

                            </div>
                        </div>
                    </div>

                        <?php
                        $active = '';
                        $icon = '<i class="fa fa-plus-circle" aria-hidden="true"></i>';
                        ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script>

    $('.nav-link').click(function() {

        $('.nav-link').removeClass("active");
        $('.nav-link').removeClass("active-item");
        $('.tab-pane').removeClass("active");
        $('.tab-pane').removeClass("show");
        $(this).addClass('active');
        $(this).addClass('active-item');
        var target = $(this).data('bs-target');
        $(target).addClass('active show')

    });
    // $('.button-link').click(function() {
    //     out =    ' <i class="fa fa-minus-circle" aria-hidden="true"></i>';
    //
    //     $(this).html(out)
    //
    // });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp7.4\htdocs\Matlob-laravel\resources\views/front/Faq.blade.php ENDPATH**/ ?>